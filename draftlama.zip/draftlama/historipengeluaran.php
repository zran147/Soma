<?php include('config.php');
session_start();
$username='';
$username = $_SESSION['username']
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>SOMA|Target</title>
</head>
<body>
  <h1>SOMA | Solusi Mahasiswa</h1>
  <h2>Riwayat Pengeluaran</h2>
  <table border="1">
	<thead>
		<tr>
			<!-- <th>ID User</th> -->
			<th>Nama</th>
			<th>Deskripsi</th>
			<th>Nominal</th>
			<th>Deadline</th>
			<th>Link Pembelian</th>
		</tr>
	</thead>
	<tbody>

  <?php
		$query = pg_query($db,"SELECT * FROM target where username = '$username' Order BY deadline asc ");
		// $query = pg_query($db, $sql);


		while($siswa = pg_fetch_array($query)){
			echo "<tr>";

			// echo "<td>".$siswa['id_user']."</td>";

			echo "<td>".$siswa['id_target']."</td>";
			echo "<td>".$siswa['deskripsi']."</td>";
			echo "<td>".$siswa['nominal']."</td>";
			echo "<td>".$siswa['deadline']."</td>";
			echo "<td>".$siswa['link_pembelian']."</td>";
			echo "</tr>";

			}


		?>

	</tbody>
	</table>

	<p>
		Total: <?php echo pg_num_rows($query) ?></p>
	</p>

</body>
</html>
