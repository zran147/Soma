<?php include('config.php');
session_start();
$username='';
$username = $_SESSION['username']
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>SOMA|Target</title>
</head>
<body>
  <h1>SOMA | Solusi Mahasiswa</h1>
  <h2>Riwayat Pemasukan</h2>
  <table border="1">
	<thead>
		<tr>
			<!-- <th>ID User</th> -->
			<th>ID Pemasukan</th>
			<th>Kategori Pemasukan</th>
			<th>Tanggal Pemasukan</th>
			<th>Nominal</th>
			<th>Deskripsi</th>
		
		</tr>
	</thead>
	<tbody>

  <?php
		$query = pg_query($db,"SELECT * FROM pemasukan where username = '$username' Order BY tanggal_pemasukan asc ");
		// $query = pg_query($db, $sql);


		while($siswa = pg_fetch_array($query)){
			echo "<tr>";

			// echo "<td>".$siswa['id_user']."</td>";

			echo "<td>".$siswa['id_pemasukan']."</td>";
			echo "<td>".$siswa['kategori_pemasukan']."</td>";
			echo "<td>".$siswa['tanggal_pemasukan']."</td>";
			echo "<td>".$siswa['nominal']."</td>";
			echo "<td>".$siswa['deskripsi']."</td>";
			echo "</tr>";

			}


		?>

	</tbody>
	</table>

	<p>
		Total: <?php echo pg_num_rows($query) ?></p>
	</p>

</body>
</html>
