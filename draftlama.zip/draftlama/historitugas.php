<?php include('config.php');
session_start();
$username='';
$username = $_SESSION['username']
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>SOMA|Tugas</title>
</head>
<body>
  <h1>SOMA | Solusi Mahasiswa</h1>
  <h2>Riwayat Tugas</h2>
  <table border="1">
	<thead>
		<tr>
			<!-- <th>ID User</th> -->
			<th>ID Tugas</th>
			<th>Nama Tugas</th>
			<th>Mata Kuliah</th>
			<th>Deadline</th>
			<th>Link Pengumpulan</th>
			<th>Tindakan</th>
		</tr>
	</thead>
	<tbody>

  <?php
		$query = pg_query($db,"SELECT * FROM tugas where username = '$username' Order BY deadline asc ");
		// $query = pg_query($db, $sql);


		while($siswa = pg_fetch_array($query)){
			echo "<tr>";

			// echo "<td>".$siswa['id_user']."</td>";
			echo "<td>".$siswa['id_tugas']."</td>";
			echo "<td>".$siswa['nama_tugas']."</td>";
			echo "<td>".$siswa['mata_kuliah']."</td>";
			echo "<td>".$siswa['deadline']."</td>";
			echo "<td>".$siswa['link_pengumpulan']."</td>";
			echo "<td>";
			echo "<a href='hapus_tugas.php?id_tugas=".$siswa['id_tugas']."'><p>Hapus</a>";  
			echo "<a href='edit_tugas.php?id_tugas=".$siswa['id_tugas']."'><p>Edit</a>";  
			echo "</td>";
			
			echo "</tr>";

			}


		?>

	</tbody>
	</table>

	<p>Total: <?php echo pg_num_rows($query) ?></p>



 </p>

</body>
</html>
