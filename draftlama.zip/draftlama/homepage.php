<?php include('config.php');
session_start();
$username = $_SESSION['username'];
$saldo  = $_SESSION['saldo'];
// $query = pg_query($db,"SELECT saldo from users where username = '$username' ")
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SOMA</title>

</head>
<body>
  <!-- <php
  $saldo = pg_query($db,"SELECT saldo From users where ");
  $saldo = pg_fetch_row($db);
  ?> -->
  <h3>Welcome <?php echo $_SESSION['nama'];?> to<br></b></h3>
  <h1>SOMA | Solusi Mahasiswa</h1>
  <h2>Saldo<br>Rp <?php echo  number_format($saldo,2,',','.');?></br></h2>
  <h3>Menu</h3>
      <a href="homepage.php">Home</a><br>
      <a href="pemasukan.php">Pemasukan</a><br>
      <a href="pengeluaran.php">Pengeluaran</a><br>
      <a href="tugas.php">Tugas</a><br>
      <a href="target.php">Target</a><br>
 
 <p>
 <a href="index.php">Log Out</a>
 </p>
</body>
</html>

<?php if (isset($_GET['status'])): ?>
  <p>
    <?php
    if ($_GET['status'] == 'sukses') {
      echo "proses berhasil!";
    } else {
      echo "proses gagal!";
    }
    return false;
    ?>
  </p>
<?php endif; ?>
